<?php 
include('../connection.php');
session_start();

if ($_SESSION['updateSet']=="phone") { 
    $phone = $_POST['update-phone'];
    $userId = $_SESSION['userId'];
    $query = "UPDATE custumer SET cus_phone= '$phone' WHERE cus_id = $userId";
    if (mysqli_query($conn, $query)){
        $_SESSION['updateSet'] = "Success";
        header("Location: ..\profile.php");        
    } else {        
        $_SESSION['updateSet'] = "Failed";
        header("Location: ..\profile.php");     
    }

} else if ($_SESSION['updateSet']=="address"){ 
    $address = $_POST['update-address'];
    $userId = $_SESSION['userId'];
    $query = "UPDATE custumer SET cus_address = '$address' WHERE cus_id = $userId";
    if (mysqli_query($conn, $query)){
        $_SESSION['updateSet'] = "Success";
        header("Location: ..\profile.php");        
    } else {        
        $_SESSION['updateSet'] = "Failed";
        header("Location: ..\profile.php");     
    }

} else if ($_SESSION['updateSet']=="profile"){
    if (isset($_POST['update-phone'])){
        
    }

} 

?>