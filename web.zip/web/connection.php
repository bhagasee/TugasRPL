<?php
$hostName = "localhost";
$userName = "root";
$password = "";
// $userName = "id20382767_mimin";
// $password = "Mm2W-%4+H@rGZ{7Q";
$databaseName = "id20382767_autoclub";
 $conn = new mysqli($hostName, $userName, $password, $databaseName);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
?>