-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 09, 2023 at 01:13 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `id20382767_autoclub`
--

-- --------------------------------------------------------

--
-- Table structure for table `cars`
--

CREATE TABLE `cars` (
  `car_id` int(11) NOT NULL,
  `car_status` varchar(10) NOT NULL COMMENT 'Opsinya Brand New, Second, Rental, Sold',
  `car_thumbnail` text DEFAULT NULL COMMENT 'Gambar yang ditampilkan utama',
  `car_year` int(11) NOT NULL COMMENT 'Tahun mobil dirilis',
  `car_transmission` varchar(20) NOT NULL COMMENT 'FWD, EWD, dll',
  `car_drivetrain` varchar(5) NOT NULL,
  `car_passangers` int(10) NOT NULL COMMENT 'Jumlah penumpang',
  `car_maker` varchar(25) NOT NULL COMMENT 'Merk mobil dibuat',
  `car_model` varchar(25) NOT NULL COMMENT 'Model mobil',
  `car_kilomatres` int(25) DEFAULT NULL,
  `car_bodytype` varchar(30) NOT NULL COMMENT 'Opsinya Pickup, SUV, Coupe, Convertible, Sedan, Minicar',
  `car_engine` varchar(20) NOT NULL COMMENT 'Formatnya xxx HP xxL Vx',
  `car_tranmission` varchar(30) NOT NULL,
  `car_exteriorcolor` varchar(25) NOT NULL COMMENT 'Warna kalau bisa pakai kata umum ex, black, red,orange',
  `car_interiorcolor` varchar(25) NOT NULL COMMENT 'Warna kalau bisa pakai kata umum ex, black, red,orange',
  `car_fuel` varchar(25) NOT NULL COMMENT 'Jenis bensin',
  `car_description` text NOT NULL COMMENT 'Boleh dikosongkan',
  `car_minus` text DEFAULT NULL,
  `car_testdrive` int(11) DEFAULT NULL,
  `car_price` int(10) NOT NULL COMMENT 'Harga sebanyak 3 digit ',
  `car_pricetext` varchar(10) NOT NULL COMMENT 'Opsinya Million dan Billion',
  `car_date` date NOT NULL DEFAULT current_timestamp() COMMENT 'Tanggal data mobil dimasukan ke database'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `cars`
--

INSERT INTO `cars` (`car_id`, `car_status`, `car_thumbnail`, `car_year`, `car_transmission`, `car_drivetrain`, `car_passangers`, `car_maker`, `car_model`, `car_kilomatres`, `car_bodytype`, `car_engine`, `car_tranmission`, `car_exteriorcolor`, `car_interiorcolor`, `car_fuel`, `car_description`, `car_minus`, `car_testdrive`, `car_price`, `car_pricetext`, `car_date`) VALUES
(1, 'Brand New', 'images\\photos\\2017_nissan_maxima-pic-803819593088110024-1024x768.jpeg', 2017, 'Auto', 'FWD', 5, 'Nissan', 'Maxima', 0, 'Sedan', '300 hp 3.5L  V-6 ', 'Dual-Clutch Automatic', ' Dark Grey', ' Jet Black', 'Gasoline ', '', NULL, NULL, 115, 'Million', '2023-03-03'),
(2, 'Second', 'images\\photos\\88402_1.jpg', 2018, 'Auto', 'FWD', 5, 'BMW', '320i', 45564, 'Sedan', '180 hp  2.0L  V-4', 'Dual-Clutch Automatic', 'White', 'Black', 'Gasoline ', '18 Temuan: Kap Mesin Stonechip Fender kanan depan Stonechip Fender kiri depan Stonechip Pintu Depan Kanan Baret Pintu Depan Kiri Baret Bumper Belakang Baret Fender belakang kanan Stone chip Pintu belakang kanan Stonechip Pintu belakang kiri Stonechip Gril Depan Baret Kaca depan Stonechip Kaca kanan depan Kaca film gores Kaca Belakang Gores Spion Kanan Baret Kondisi Velg Depan Kiri Baret & Cat terkelupas Kondisi Velg Depan Kanan Cat terkelupas Kondisi Velg Belakang Kiri Baret & Cat terkelupas Kondisi Velg Belakang Kanan Cat terkelupas', NULL, NULL, 506, 'Million', '2023-03-01'),
(3, 'Second', 'images\\photos\\Toyota-Fortuner-Facelift-Indonesia-Front.jpg', 2014, 'Auto', 'AWD', 7, 'Toyota', 'Fortuner', 45564, 'SUV', '158 hp 2.7L V-4', 'Dual-Clutch Automatic', 'White', 'Black', 'Petrol', '', NULL, NULL, 239, 'Million', '2023-03-01'),
(4, 'Rental', 'images\\photos\\01.jpg', 2023, 'Auto', 'AWD', 7, 'Toyota', 'Land Cruiser EXR', 0, 'SUV', '271 hp 4.0L V-6', 'Dual-Clutch Automatic', 'White', 'Black', 'Petrol', 'With a starting price of AED 233,900, the Toyota Land Cruiser competes with very well-known competitors . This Japanese Premium large suv car is available in 8 versions .\r\nAvailable in 3 engine options, the Land Cruiser offers new car buyers a 3.3-liter , 4.0-liter and 3.5-liter engine to choose from. Known for its reliability, the Toyota Land Cruiser comes with features such as: Acoustic Front Windshield, Center Arm Rest, 12V Socket - Front Only, Moving object detection system, among others.', NULL, NULL, 3, 'Million', '2023-03-01'),
(5, 'Brand New', 'images\\photos\\01.jpg', 2023, 'Auto', 'AWD', 7, 'Toyota', 'Land Cruiser EXR', 0, 'SUV', '271 hp 4.0L V-6', 'Dual-Clutch Automatic', 'White', 'Black', 'Petrol', 'With a starting price of AED 233,900, the Toyota Land Cruiser competes with very well-known competitors . This Japanese Premium large suv car is available in 8 versions .\r\nAvailable in 3 engine options, the Land Cruiser offers new car buyers a 3.3-liter , 4.0-liter and 3.5-liter engine to choose from. Known for its reliability, the Toyota Land Cruiser comes with features such as: Acoustic Front Windshield, Center Arm Rest, 12V Socket - Front Only, Moving object detection system, among others.', NULL, NULL, 2, 'Billion', '2023-03-01');

-- --------------------------------------------------------

--
-- Table structure for table `custumer`
--

CREATE TABLE `custumer` (
  `cus_id` int(11) NOT NULL,
  `cus_name` varchar(125) NOT NULL,
  `cus_password` varchar(10) NOT NULL,
  `cus_email` varchar(255) NOT NULL,
  `cus_phone` varchar(25) DEFAULT NULL,
  `cus_address` text DEFAULT NULL,
  `cus_post_code` varchar(5) DEFAULT NULL COMMENT 'Kode pos pelanggan',
  `cus_verified` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'Status verifikasi akun',
  `cus_subscribe` tinyint(1) NOT NULL DEFAULT 1,
  `cus_lastlog` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `custumer`
--

INSERT INTO `custumer` (`cus_id`, `cus_name`, `cus_password`, `cus_email`, `cus_phone`, `cus_address`, `cus_post_code`, `cus_verified`, `cus_subscribe`, `cus_lastlog`) VALUES
(1, 'Dewei Ratu', 'ratu', 'dewiratu@mail.com', '072245891543', '', '', 1, 1, '2023-04-22'),
(8, 'rioardana', 'rioardana', 'sanghwakyung@gmail.com', '', NULL, NULL, 0, 1, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `newslatter`
--

CREATE TABLE `newslatter` (
  `nw_id` int(11) NOT NULL,
  `nw_cus` int(11) DEFAULT NULL,
  `nw_name` varchar(125) NOT NULL,
  `nw_email` int(225) NOT NULL,
  `nw_status` tinyint(1) NOT NULL DEFAULT 1,
  `nw_start` date NOT NULL DEFAULT current_timestamp(),
  `nw_stop` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pictures`
--

CREATE TABLE `pictures` (
  `pic_id` int(11) NOT NULL,
  `pic_car` int(11) NOT NULL COMMENT '	Merujuk pada index tabel cars',
  `pic_path` text NOT NULL COMMENT 'Berisikan lokasi penyimpanan foto Contoh iamges/photos/xxxx.jpg'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `pictures`
--

INSERT INTO `pictures` (`pic_id`, `pic_car`, `pic_path`) VALUES
(1, 1, 'images\\photos\\2017_nissan_maxima-pic-620492937931546633-1024x768.jpeg'),
(2, 1, 'images\\photos\\2017_nissan_maxima-pic-803819593088110024-1024x768.jpeg'),
(3, 1, 'images\\photos\\2017_nissan_maxima-pic-1845729666399152904-1024x768.jpeg'),
(4, 1, 'images\\photos\\2017_nissan_maxima-pic-2014820638541239144-1024x768.jpeg'),
(5, 1, 'images\\photos\\2017_nissan_maxima-pic-3017402972173507506-1024x768.jpeg'),
(6, 3, 'images\\photos\\2017_nissan_maxima-pic-6751552886793168718-1024x768.jpeg'),
(7, 3, 'images\\photos\\2017_nissan_maxima-pic-6976057528539861543-1024x768.jpeg'),
(8, 2, 'images\\photos\\2017_nissan_maxima-pic-7343079518108597209-1024x768.jpeg'),
(9, 2, 'images\\photos\\2017_nissan_maxima-pic-8922343800962476844-1024x768.jpeg'),
(10, 4, 'images\\photos\\01.png'),
(11, 4, 'images\\photos\\02.png'),
(12, 5, 'images\\photos\\01.png'),
(13, 5, 'images\\photos\\02.png');

-- --------------------------------------------------------

--
-- Table structure for table `schedule`
--

CREATE TABLE `schedule` (
  `sch_id` int(11) NOT NULL,
  `sch_time` int(11) NOT NULL COMMENT '	Merujuk pada index tabel timeSchedule',
  `sch_car` int(11) NOT NULL COMMENT '	Merujuk pada index tabel cars',
  `sch_cus` int(11) NOT NULL COMMENT '	Merujuk pada index tabel custumer',
  `sch_status` varchar(10) NOT NULL COMMENT 'Opsi On_Time,On-Call,On-Rode, Delay, Cancel'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `schedule`
--

INSERT INTO `schedule` (`sch_id`, `sch_time`, `sch_car`, `sch_cus`, `sch_status`) VALUES
(1, 2, 1, 1, 'On-Time');

-- --------------------------------------------------------

--
-- Table structure for table `shopping`
--

CREATE TABLE `shopping` (
  `shop_id` int(11) NOT NULL,
  `shop_car` int(11) NOT NULL COMMENT 'Merujuk pada index tabel cars',
  `shop_cus` int(11) NOT NULL COMMENT 'Merujuk pada index tabel custumer',
  `shop_payment` varchar(40) NOT NULL COMMENT 'Total pembayaran',
  `shop_status` varchar(10) NOT NULL COMMENT 'Status pembayaran',
  `shop_date_payment` date DEFAULT NULL COMMENT 'Tanggal jatuh tempo pembayaran',
  `shop_date_created` date NOT NULL DEFAULT current_timestamp() COMMENT 'Tanggal dibayar'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `shopping`
--

INSERT INTO `shopping` (`shop_id`, `shop_car`, `shop_cus`, `shop_payment`, `shop_status`, `shop_date_payment`, `shop_date_created`) VALUES
(1, 1, 1, '115 Million', '', NULL, '2023-04-19');

-- --------------------------------------------------------

--
-- Table structure for table `timeschedule`
--

CREATE TABLE `timeschedule` (
  `tmsch_id` int(11) NOT NULL,
  `tmsch_time` time NOT NULL,
  `tmsch_status` varchar(10) DEFAULT NULL COMMENT 'Opsi Available, Cancel, Fully Booked'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `timeschedule`
--

INSERT INTO `timeschedule` (`tmsch_id`, `tmsch_time`, `tmsch_status`) VALUES
(1, '09:00:00', 'Available'),
(2, '09:30:00', 'Available'),
(3, '10:00:00', 'Available'),
(4, '10:30:00', 'Available'),
(5, '11:00:00', 'Available'),
(6, '11:30:00', 'Available'),
(7, '12:00:00', 'Available'),
(8, '13:00:00', 'Available'),
(9, '13:30:00', 'Available'),
(10, '14:00:00', 'Available'),
(11, '14:30:00', 'Available'),
(12, '15:00:00', 'Available'),
(13, '15:30:00', 'Available'),
(14, '16:00:00', 'Available'),
(15, '16:30:00', 'Available');

-- --------------------------------------------------------

--
-- Table structure for table `videos`
--

CREATE TABLE `videos` (
  `vid_id` int(11) NOT NULL,
  `vid_car` int(11) NOT NULL COMMENT '	Merujuk pada index tabel cars',
  `vid_path` text NOT NULL COMMENT 'Berisikan link video seperti youtube'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cars`
--
ALTER TABLE `cars`
  ADD PRIMARY KEY (`car_id`);

--
-- Indexes for table `custumer`
--
ALTER TABLE `custumer`
  ADD PRIMARY KEY (`cus_id`);

--
-- Indexes for table `newslatter`
--
ALTER TABLE `newslatter`
  ADD PRIMARY KEY (`nw_id`),
  ADD UNIQUE KEY `nw_cus` (`nw_cus`);

--
-- Indexes for table `pictures`
--
ALTER TABLE `pictures`
  ADD PRIMARY KEY (`pic_id`),
  ADD KEY `pic_car` (`pic_car`);

--
-- Indexes for table `schedule`
--
ALTER TABLE `schedule`
  ADD PRIMARY KEY (`sch_id`),
  ADD KEY `sch_time` (`sch_time`,`sch_car`,`sch_cus`),
  ADD KEY `sch_car` (`sch_car`),
  ADD KEY `sch_cus` (`sch_cus`);

--
-- Indexes for table `shopping`
--
ALTER TABLE `shopping`
  ADD PRIMARY KEY (`shop_id`),
  ADD KEY `shop_car` (`shop_car`,`shop_cus`),
  ADD KEY `shop_cus` (`shop_cus`);

--
-- Indexes for table `timeschedule`
--
ALTER TABLE `timeschedule`
  ADD PRIMARY KEY (`tmsch_id`);

--
-- Indexes for table `videos`
--
ALTER TABLE `videos`
  ADD PRIMARY KEY (`vid_id`),
  ADD KEY `vid_car` (`vid_car`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cars`
--
ALTER TABLE `cars`
  MODIFY `car_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `custumer`
--
ALTER TABLE `custumer`
  MODIFY `cus_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `newslatter`
--
ALTER TABLE `newslatter`
  MODIFY `nw_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pictures`
--
ALTER TABLE `pictures`
  MODIFY `pic_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `schedule`
--
ALTER TABLE `schedule`
  MODIFY `sch_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `shopping`
--
ALTER TABLE `shopping`
  MODIFY `shop_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `timeschedule`
--
ALTER TABLE `timeschedule`
  MODIFY `tmsch_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `videos`
--
ALTER TABLE `videos`
  MODIFY `vid_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `newslatter`
--
ALTER TABLE `newslatter`
  ADD CONSTRAINT `newslatter_ibfk_1` FOREIGN KEY (`nw_cus`) REFERENCES `custumer` (`cus_id`) ON DELETE SET NULL ON UPDATE NO ACTION;

--
-- Constraints for table `pictures`
--
ALTER TABLE `pictures`
  ADD CONSTRAINT `pictures_ibfk_1` FOREIGN KEY (`pic_car`) REFERENCES `cars` (`car_id`) ON DELETE CASCADE;

--
-- Constraints for table `schedule`
--
ALTER TABLE `schedule`
  ADD CONSTRAINT `schedule_ibfk_1` FOREIGN KEY (`sch_time`) REFERENCES `timeschedule` (`tmsch_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `schedule_ibfk_2` FOREIGN KEY (`sch_car`) REFERENCES `cars` (`car_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `schedule_ibfk_3` FOREIGN KEY (`sch_cus`) REFERENCES `custumer` (`cus_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `shopping`
--
ALTER TABLE `shopping`
  ADD CONSTRAINT `shopping_ibfk_1` FOREIGN KEY (`shop_cus`) REFERENCES `custumer` (`cus_id`) ON DELETE NO ACTION,
  ADD CONSTRAINT `shopping_ibfk_2` FOREIGN KEY (`shop_car`) REFERENCES `cars` (`car_id`) ON DELETE NO ACTION;

--
-- Constraints for table `videos`
--
ALTER TABLE `videos`
  ADD CONSTRAINT `videos_ibfk_1` FOREIGN KEY (`vid_car`) REFERENCES `cars` (`car_id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
